--
-- PostgreSQL database dump
--

\restrict FenfKBKadz5FnKWfLHTndNCG0WKEPGz8rashJ1zxBDeElLdThYvTjKXhYtxsSvC

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

-- Started on 2026-02-13 06:03:20 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 2 (class 3079 OID 17845)
-- Name: timescaledb; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS timescaledb WITH SCHEMA public;


--
-- TOC entry 4455 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION timescaledb; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION timescaledb IS 'Enables scalable inserts and complex queries for time-series data (Community Edition)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 310 (class 1259 OID 32986)
-- Name: advance_directives; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.advance_directives (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    directive_type character varying(30) NOT NULL,
    rea_status character varying(10) NOT NULL,
    intensive_care boolean NOT NULL,
    mechanical_ventilation boolean NOT NULL,
    dialysis boolean NOT NULL,
    artificial_nutrition boolean NOT NULL,
    trusted_person_name character varying(200),
    trusted_person_phone character varying(20),
    trusted_person_relation character varying(50),
    trusted_person_contact_id uuid,
    document_date date,
    storage_location character varying(255),
    is_valid boolean NOT NULL,
    notes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 301 (class 1259 OID 26249)
-- Name: alarms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alarms (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    vital_sign_id uuid,
    parameter character varying(30) NOT NULL,
    value double precision NOT NULL,
    threshold_min double precision,
    threshold_max double precision,
    severity character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    triggered_at timestamp with time zone NOT NULL,
    acknowledged_at timestamp with time zone,
    acknowledged_by uuid
);


--
-- TOC entry 293 (class 1259 OID 26169)
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- TOC entry 294 (class 1259 OID 26174)
-- Name: app_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_users (
    id uuid NOT NULL,
    keycloak_id character varying(255) NOT NULL,
    username character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    is_active boolean NOT NULL,
    last_login timestamp with time zone
);


--
-- TOC entry 311 (class 1259 OID 33004)
-- Name: appointments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointments (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    encounter_id uuid,
    appointment_type character varying(30) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    location character varying(255),
    scheduled_date date NOT NULL,
    start_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone,
    duration_minutes integer NOT NULL,
    assigned_to uuid,
    assigned_name character varying(200),
    status character varying(20) NOT NULL,
    is_recurring boolean NOT NULL,
    recurrence_rule character varying(30),
    recurrence_end date,
    parent_appointment_id uuid,
    transport_required boolean NOT NULL,
    transport_type character varying(30),
    transport_notes text,
    notes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 295 (class 1259 OID 26182)
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    user_role character varying(20) NOT NULL,
    action character varying(50) NOT NULL,
    resource_type character varying(50) NOT NULL,
    resource_id character varying(100),
    details jsonb NOT NULL,
    ip_address character varying(45),
    created_at timestamp with time zone NOT NULL
);


--
-- TOC entry 306 (class 1259 OID 32924)
-- Name: clinical_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clinical_notes (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    encounter_id uuid,
    note_type character varying(30) NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    summary text,
    author_id uuid,
    co_signed_by uuid,
    co_signed_at timestamp with time zone,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    is_confidential boolean DEFAULT false NOT NULL,
    tags jsonb,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 307 (class 1259 OID 32947)
-- Name: consents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consents (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    consent_type character varying(30) NOT NULL,
    status character varying(20) NOT NULL,
    granted_at timestamp with time zone,
    granted_by character varying(200),
    valid_from date,
    valid_until date,
    revoked_at timestamp with time zone,
    revoked_reason text,
    witness_name character varying(200),
    notes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 323 (class 1259 OID 65709)
-- Name: consultations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consultations (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    encounter_id uuid,
    specialty character varying(100) NOT NULL,
    urgency character varying(20) DEFAULT 'routine'::character varying,
    question text NOT NULL,
    clinical_context text,
    requested_by uuid,
    requested_at timestamp with time zone DEFAULT now(),
    consultant_id uuid,
    consultant_name character varying(200),
    response text,
    recommendations text,
    responded_at timestamp with time zone,
    status character varying(20) DEFAULT 'requested'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 312 (class 1259 OID 33028)
-- Name: death_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.death_notifications (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    contact_name character varying(200) NOT NULL,
    contact_phone character varying(20),
    contact_email character varying(255),
    contact_role character varying(100),
    emergency_contact_id uuid,
    priority integer NOT NULL,
    instructions text,
    created_at timestamp with time zone NOT NULL
);


--
-- TOC entry 313 (class 1259 OID 33046)
-- Name: discharge_criteria; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discharge_criteria (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    encounter_id uuid,
    planned_discharge_date date,
    actual_discharge_date date,
    crp_declining boolean NOT NULL,
    crp_below_50 boolean NOT NULL,
    afebrile_48h boolean NOT NULL,
    oral_stable_48h boolean NOT NULL,
    clinical_improvement boolean NOT NULL,
    aftercare_organized boolean NOT NULL,
    followup_gp character varying(255),
    followup_gp_date date,
    followup_spitex character varying(255),
    followup_spitex_date date,
    notes text,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 297 (class 1259 OID 26198)
-- Name: emergency_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.emergency_contacts (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    relationship_type character varying(50) NOT NULL,
    phone character varying(20) NOT NULL,
    is_primary boolean NOT NULL,
    email character varying(255),
    address character varying(255),
    priority integer DEFAULT 0 NOT NULL,
    is_legal_representative boolean DEFAULT false NOT NULL,
    is_key_person boolean DEFAULT false NOT NULL,
    notes text
);


--
-- TOC entry 298 (class 1259 OID 26208)
-- Name: encounters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.encounters (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    encounter_type character varying(30) NOT NULL,
    ward character varying(50),
    bed character varying(20),
    admitted_at timestamp with time zone NOT NULL,
    discharged_at timestamp with time zone,
    reason text,
    attending_physician_id uuid
);


--
-- TOC entry 320 (class 1259 OID 65652)
-- Name: fluid_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fluid_entries (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    encounter_id uuid,
    direction character varying(10) NOT NULL,
    category character varying(30) NOT NULL,
    display_name character varying(200) NOT NULL,
    volume_ml double precision NOT NULL,
    route character varying(30),
    recorded_at timestamp with time zone NOT NULL,
    recorded_by uuid,
    notes text,
    created_at timestamp with time zone NOT NULL
);


--
-- TOC entry 316 (class 1259 OID 40995)
-- Name: home_visits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.home_visits (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    appointment_id uuid,
    encounter_id uuid,
    assigned_nurse_id uuid,
    assigned_nurse_name character varying(200),
    status character varying(20) NOT NULL,
    planned_date date NOT NULL,
    planned_start timestamp with time zone NOT NULL,
    planned_end timestamp with time zone,
    actual_arrival timestamp with time zone,
    actual_departure timestamp with time zone,
    travel_time_minutes integer,
    visit_duration_minutes integer,
    vital_signs_recorded boolean NOT NULL,
    medication_administered boolean NOT NULL,
    wound_care_performed boolean NOT NULL,
    iv_therapy_performed boolean NOT NULL,
    blood_drawn boolean NOT NULL,
    patient_condition character varying(20),
    documentation text,
    notes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 299 (class 1259 OID 26221)
-- Name: insurances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.insurances (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    insurer_name character varying(255) NOT NULL,
    policy_number character varying(50) NOT NULL,
    insurance_type character varying(30) NOT NULL,
    valid_from date,
    valid_until date,
    franchise integer,
    kostengutsprache boolean DEFAULT false NOT NULL,
    kostengutsprache_bis date,
    garant character varying(30),
    bvg_number character varying(50),
    notes text
);


--
-- TOC entry 319 (class 1259 OID 65630)
-- Name: lab_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lab_results (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    encounter_id uuid,
    analyte character varying(50) NOT NULL,
    loinc_code character varying(20),
    display_name character varying(100) NOT NULL,
    value double precision NOT NULL,
    unit character varying(20) NOT NULL,
    ref_min double precision,
    ref_max double precision,
    flag character varying(10),
    interpretation character varying(20),
    trend character varying(5),
    previous_value double precision,
    category character varying(30) DEFAULT 'chemistry'::character varying NOT NULL,
    sample_type character varying(30),
    collected_at timestamp with time zone,
    resulted_at timestamp with time zone NOT NULL,
    ordered_by uuid,
    validated_by uuid,
    order_number character varying(50),
    notes text,
    extra jsonb,
    created_at timestamp with time zone NOT NULL
);


--
-- TOC entry 324 (class 1259 OID 65732)
-- Name: medical_letters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medical_letters (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    encounter_id uuid,
    letter_type character varying(30) NOT NULL,
    title character varying(255) NOT NULL,
    recipient_name character varying(200),
    recipient_institution character varying(255),
    recipient_email character varying(255),
    diagnosis text,
    history text,
    findings text,
    therapy text,
    procedures text,
    recommendations text,
    medication_on_discharge text,
    follow_up text,
    content text,
    author_id uuid,
    co_signed_by uuid,
    co_signed_at timestamp with time zone,
    status character varying(20) DEFAULT 'draft'::character varying,
    sent_at timestamp with time zone,
    sent_via character varying(30),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 308 (class 1259 OID 32960)
-- Name: medical_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medical_providers (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    provider_type character varying(30) NOT NULL,
    name character varying(255) NOT NULL,
    contact_person character varying(200),
    phone character varying(20),
    email character varying(255),
    hin_email character varying(255),
    gln_number character varying(13),
    address character varying(255),
    speciality character varying(100),
    notes text
);


--
-- TOC entry 303 (class 1259 OID 32869)
-- Name: medication_administrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medication_administrations (
    id uuid NOT NULL,
    medication_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    administered_at timestamp with time zone NOT NULL,
    administered_by uuid,
    dose_given character varying(50) NOT NULL,
    dose_unit character varying(20) NOT NULL,
    route character varying(30) NOT NULL,
    status character varying(20) NOT NULL,
    reason_not_given text,
    notes text
);


--
-- TOC entry 302 (class 1259 OID 32851)
-- Name: medications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medications (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    encounter_id uuid,
    name character varying(255) NOT NULL,
    generic_name character varying(255),
    atc_code character varying(10),
    dose character varying(50) NOT NULL,
    dose_unit character varying(20) NOT NULL,
    route character varying(30) NOT NULL,
    frequency character varying(100) NOT NULL,
    start_date date NOT NULL,
    end_date date,
    status character varying(20) NOT NULL,
    reason text,
    notes text,
    prescribed_by uuid,
    is_prn boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 304 (class 1259 OID 32888)
-- Name: nursing_assessments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nursing_assessments (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    encounter_id uuid,
    assessment_type character varying(30) NOT NULL,
    total_score integer NOT NULL,
    max_score integer,
    risk_level character varying(20),
    items jsonb NOT NULL,
    notes text,
    assessed_at timestamp with time zone NOT NULL,
    assessed_by uuid,
    created_at timestamp with time zone NOT NULL
);


--
-- TOC entry 325 (class 1259 OID 65753)
-- Name: nursing_diagnoses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nursing_diagnoses (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    encounter_id uuid,
    nanda_code character varying(20),
    title character varying(255) NOT NULL,
    domain character varying(100),
    defining_characteristics text,
    related_factors text,
    risk_factors text,
    goals text,
    interventions text,
    evaluation text,
    priority character varying(20) DEFAULT 'normal'::character varying,
    status character varying(20) DEFAULT 'active'::character varying,
    diagnosed_by uuid,
    diagnosed_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 305 (class 1259 OID 32906)
-- Name: nursing_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nursing_entries (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    encounter_id uuid,
    category character varying(30) NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    priority character varying(20) NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    recorded_by uuid,
    is_handover boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 327 (class 1259 OID 65796)
-- Name: nutrition_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nutrition_orders (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    encounter_id uuid,
    diet_type character varying(50) NOT NULL,
    texture character varying(30),
    supplements text,
    restrictions text,
    allergies text,
    caloric_target integer,
    protein_target double precision,
    fluid_target integer,
    special_instructions text,
    status character varying(20) DEFAULT 'active'::character varying,
    start_date date NOT NULL,
    end_date date,
    ordered_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 328 (class 1259 OID 65817)
-- Name: nutrition_screenings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nutrition_screenings (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    screening_type character varying(30) NOT NULL,
    total_score integer NOT NULL,
    risk_level character varying(20) NOT NULL,
    items jsonb DEFAULT '{}'::jsonb,
    notes text,
    screened_at timestamp with time zone DEFAULT now(),
    screened_by uuid,
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 309 (class 1259 OID 32973)
-- Name: palliative_care; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.palliative_care (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    is_active boolean NOT NULL,
    activated_at timestamp with time zone,
    activated_by uuid,
    reserve_morphin character varying(100),
    reserve_midazolam character varying(100),
    reserve_haloperidol character varying(100),
    reserve_scopolamin character varying(100),
    reserve_other text,
    palliative_service_name character varying(255),
    palliative_service_phone character varying(20),
    palliative_service_email character varying(255),
    goals_of_care text,
    notes text,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 314 (class 1259 OID 33064)
-- Name: patient_wishes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patient_wishes (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    quality_of_life text,
    autonomy_preferences text,
    pain_management text,
    decision_maker character varying(200),
    decision_maker_contact_id uuid,
    sleep_preferences text,
    nutrition_preferences text,
    family_wishes text,
    pet_info text,
    spiritual_needs text,
    other_wishes text,
    recorded_by uuid,
    recorded_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 296 (class 1259 OID 26190)
-- Name: patients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patients (
    id uuid NOT NULL,
    ahv_number character varying(16),
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    date_of_birth date NOT NULL,
    gender character varying(20) NOT NULL,
    blood_type character varying(5),
    phone character varying(20),
    email character varying(255),
    address_street character varying(255),
    address_zip character varying(10),
    address_city character varying(100),
    address_canton character varying(2),
    language character varying(5) NOT NULL,
    status character varying(20) NOT NULL,
    is_deleted boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 315 (class 1259 OID 40982)
-- Name: remote_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.remote_devices (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    device_type character varying(30) NOT NULL,
    device_name character varying(200) NOT NULL,
    serial_number character varying(100),
    manufacturer character varying(200),
    is_online boolean NOT NULL,
    last_seen_at timestamp with time zone,
    battery_level integer,
    last_reading_value character varying(50),
    last_reading_unit character varying(20),
    last_reading_at timestamp with time zone,
    alert_threshold_low character varying(50),
    alert_threshold_high character varying(50),
    installed_at date,
    notes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 317 (class 1259 OID 41019)
-- Name: self_medication_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.self_medication_logs (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    medication_id uuid NOT NULL,
    scheduled_time timestamp with time zone NOT NULL,
    confirmed_at timestamp with time zone,
    status character varying(20) NOT NULL,
    notes text,
    created_at timestamp with time zone NOT NULL
);


--
-- TOC entry 326 (class 1259 OID 65776)
-- Name: shift_handovers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shift_handovers (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    encounter_id uuid,
    shift_type character varying(20) NOT NULL,
    handover_date date NOT NULL,
    situation text NOT NULL,
    background text,
    assessment text,
    recommendation text,
    open_tasks jsonb,
    critical_info text,
    handed_over_by uuid,
    received_by uuid,
    acknowledged_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 329 (class 1259 OID 65833)
-- Name: supply_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supply_items (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    article_number character varying(50),
    category character varying(50) NOT NULL,
    unit character varying(20) NOT NULL,
    stock_quantity integer DEFAULT 0,
    min_stock integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 330 (class 1259 OID 65844)
-- Name: supply_usages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supply_usages (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    supply_item_id uuid NOT NULL,
    encounter_id uuid,
    quantity integer NOT NULL,
    reason text,
    used_at timestamp with time zone DEFAULT now(),
    used_by uuid,
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 318 (class 1259 OID 41038)
-- Name: teleconsults; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teleconsults (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    appointment_id uuid,
    encounter_id uuid,
    physician_id uuid,
    physician_name character varying(200),
    status character varying(20) NOT NULL,
    meeting_link character varying(500),
    meeting_platform character varying(50),
    scheduled_start timestamp with time zone NOT NULL,
    scheduled_end timestamp with time zone,
    actual_start timestamp with time zone,
    actual_end timestamp with time zone,
    duration_minutes integer,
    soap_subjective text,
    soap_objective text,
    soap_assessment text,
    soap_plan text,
    technical_quality character varying(10),
    followup_required boolean NOT NULL,
    followup_notes text,
    clinical_note_id uuid,
    notes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 322 (class 1259 OID 65693)
-- Name: treatment_plan_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.treatment_plan_items (
    id uuid NOT NULL,
    plan_id uuid NOT NULL,
    item_type character varying(30) NOT NULL,
    description text NOT NULL,
    frequency character varying(100),
    duration character varying(100),
    status character varying(20) DEFAULT 'pending'::character varying,
    sort_order integer DEFAULT 0,
    notes text,
    completed_at timestamp with time zone,
    completed_by uuid,
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 321 (class 1259 OID 65671)
-- Name: treatment_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.treatment_plans (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    encounter_id uuid,
    title character varying(255) NOT NULL,
    diagnosis text NOT NULL,
    icd_code character varying(20),
    goals text NOT NULL,
    interventions text NOT NULL,
    start_date date NOT NULL,
    target_date date,
    end_date date,
    status character varying(20) DEFAULT 'active'::character varying,
    priority character varying(20) DEFAULT 'normal'::character varying,
    responsible_physician_id uuid,
    created_by uuid,
    review_date date,
    notes text,
    extra jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 300 (class 1259 OID 26231)
-- Name: vital_signs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vital_signs (
    id uuid NOT NULL,
    patient_id uuid NOT NULL,
    encounter_id uuid,
    recorded_at timestamp with time zone NOT NULL,
    recorded_by uuid,
    source character varying(20) NOT NULL,
    heart_rate double precision,
    systolic_bp double precision,
    diastolic_bp double precision,
    spo2 double precision,
    temperature double precision,
    respiratory_rate double precision,
    gcs integer,
    pain_score integer,
    extra jsonb
);


--
-- TOC entry 3894 (class 0 OID 17870)
-- Dependencies: 238
-- Data for Name: hypertable; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.hypertable (id, schema_name, table_name, associated_schema_name, associated_table_prefix, num_dimensions, chunk_sizing_func_schema, chunk_sizing_func_name, chunk_target_size, compression_state, compressed_hypertable_id, status) FROM stdin;
2	public	vital_signs	_timescaledb_internal	_hyper_2	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
\.


--
-- TOC entry 3907 (class 0 OID 18003)
-- Dependencies: 252
-- Data for Name: bgw_job; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.bgw_job (id, application_name, schedule_interval, max_runtime, max_retries, retry_period, proc_schema, proc_name, owner, scheduled, fixed_schedule, initial_start, hypertable_id, config, check_schema, check_name, timezone) FROM stdin;
\.


--
-- TOC entry 3900 (class 0 OID 17940)
-- Dependencies: 246
-- Data for Name: chunk; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.chunk (id, hypertable_id, schema_name, table_name, compressed_chunk_id, dropped, status, osm_chunk, creation_time) FROM stdin;
\.


--
-- TOC entry 3904 (class 0 OID 17983)
-- Dependencies: 250
-- Data for Name: chunk_column_stats; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.chunk_column_stats (id, hypertable_id, chunk_id, column_name, range_start, range_end, valid) FROM stdin;
\.


--
-- TOC entry 3896 (class 0 OID 17906)
-- Dependencies: 242
-- Data for Name: dimension; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.dimension (id, hypertable_id, column_name, column_type, aligned, num_slices, partitioning_func_schema, partitioning_func, interval_length, compress_interval_length, integer_now_func_schema, integer_now_func) FROM stdin;
2	2	recorded_at	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
\.


--
-- TOC entry 3898 (class 0 OID 17925)
-- Dependencies: 244
-- Data for Name: dimension_slice; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.dimension_slice (id, dimension_id, range_start, range_end) FROM stdin;
\.


--
-- TOC entry 3902 (class 0 OID 17965)
-- Dependencies: 247
-- Data for Name: chunk_constraint; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.chunk_constraint (chunk_id, dimension_slice_id, constraint_name, hypertable_constraint_name) FROM stdin;
\.


--
-- TOC entry 3917 (class 0 OID 18170)
-- Dependencies: 268
-- Data for Name: compression_chunk_size; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.compression_chunk_size (chunk_id, compressed_chunk_id, uncompressed_heap_size, uncompressed_toast_size, uncompressed_index_size, compressed_heap_size, compressed_toast_size, compressed_index_size, numrows_pre_compression, numrows_post_compression, numrows_frozen_immediately) FROM stdin;
\.


--
-- TOC entry 3916 (class 0 OID 18159)
-- Dependencies: 267
-- Data for Name: compression_settings; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.compression_settings (relid, compress_relid, segmentby, orderby, orderby_desc, orderby_nullsfirst, index) FROM stdin;
\.


--
-- TOC entry 3909 (class 0 OID 18071)
-- Dependencies: 259
-- Data for Name: continuous_agg; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.continuous_agg (mat_hypertable_id, raw_hypertable_id, parent_mat_hypertable_id, user_view_schema, user_view_name, partial_view_schema, partial_view_name, direct_view_schema, direct_view_name, materialized_only) FROM stdin;
\.


--
-- TOC entry 3918 (class 0 OID 18186)
-- Dependencies: 269
-- Data for Name: continuous_agg_migrate_plan; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.continuous_agg_migrate_plan (mat_hypertable_id, start_ts, end_ts, user_view_definition) FROM stdin;
\.


--
-- TOC entry 3919 (class 0 OID 18195)
-- Dependencies: 271
-- Data for Name: continuous_agg_migrate_plan_step; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.continuous_agg_migrate_plan_step (mat_hypertable_id, step_id, status, start_ts, end_ts, type, config) FROM stdin;
\.


--
-- TOC entry 3910 (class 0 OID 18097)
-- Dependencies: 260
-- Data for Name: continuous_aggs_bucket_function; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.continuous_aggs_bucket_function (mat_hypertable_id, bucket_func, bucket_width, bucket_origin, bucket_offset, bucket_timezone, bucket_fixed_width) FROM stdin;
\.


--
-- TOC entry 3913 (class 0 OID 18130)
-- Dependencies: 263
-- Data for Name: continuous_aggs_hypertable_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.continuous_aggs_hypertable_invalidation_log (hypertable_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- TOC entry 3911 (class 0 OID 18110)
-- Dependencies: 261
-- Data for Name: continuous_aggs_invalidation_threshold; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.continuous_aggs_invalidation_threshold (hypertable_id, watermark) FROM stdin;
\.


--
-- TOC entry 3914 (class 0 OID 18134)
-- Dependencies: 264
-- Data for Name: continuous_aggs_materialization_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.continuous_aggs_materialization_invalidation_log (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- TOC entry 3915 (class 0 OID 18143)
-- Dependencies: 265
-- Data for Name: continuous_aggs_materialization_ranges; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.continuous_aggs_materialization_ranges (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- TOC entry 3912 (class 0 OID 18120)
-- Dependencies: 262
-- Data for Name: continuous_aggs_watermark; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.continuous_aggs_watermark (mat_hypertable_id, watermark) FROM stdin;
\.


--
-- TOC entry 3908 (class 0 OID 18058)
-- Dependencies: 257
-- Data for Name: metadata; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.metadata (key, value, include_in_telemetry) FROM stdin;
install_timestamp	2026-02-09 20:08:56.617613+00	t
timescaledb_version	2.25.0	f
exported_uuid	65d0e8f7-73dc-4657-9d59-deeee5867a9d	t
\.


--
-- TOC entry 3895 (class 0 OID 17892)
-- Dependencies: 240
-- Data for Name: tablespace; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.tablespace (id, hypertable_id, tablespace_name) FROM stdin;
\.


--
-- TOC entry 4429 (class 0 OID 32986)
-- Dependencies: 310
-- Data for Name: advance_directives; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.advance_directives (id, patient_id, directive_type, rea_status, intensive_care, mechanical_ventilation, dialysis, artificial_nutrition, trusted_person_name, trusted_person_phone, trusted_person_relation, trusted_person_contact_id, document_date, storage_location, is_valid, notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4420 (class 0 OID 26249)
-- Dependencies: 301
-- Data for Name: alarms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alarms (id, patient_id, vital_sign_id, parameter, value, threshold_min, threshold_max, severity, status, triggered_at, acknowledged_at, acknowledged_by) FROM stdin;
\.


--
-- TOC entry 4412 (class 0 OID 26169)
-- Dependencies: 293
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
009_phase3c_therapy
\.


--
-- TOC entry 4413 (class 0 OID 26174)
-- Dependencies: 294
-- Data for Name: app_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_users (id, keycloak_id, username, email, role, is_active, last_login) FROM stdin;
\.


--
-- TOC entry 4430 (class 0 OID 33004)
-- Dependencies: 311
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appointments (id, patient_id, encounter_id, appointment_type, title, description, location, scheduled_date, start_time, end_time, duration_minutes, assigned_to, assigned_name, status, is_recurring, recurrence_rule, recurrence_end, parent_appointment_id, transport_required, transport_type, transport_notes, notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4414 (class 0 OID 26182)
-- Dependencies: 295
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, user_id, user_role, action, resource_type, resource_id, details, ip_address, created_at) FROM stdin;
8cdcd7aa-0579-4de4-aa6f-a649d7c7955c	00000000-0000-4000-a000-000000000001	admin	POST	/api/v1/vitals	\N	{"status": 422, "duration_ms": 4}	127.0.0.1	2026-02-12 21:43:18.847289+00
8440b7f3-e917-4327-9a55-3e434c05e195	00000000-0000-4000-a000-000000000001	admin	POST	/api/v1/vitals	\N	{"status": 422, "duration_ms": 6}	127.0.0.1	2026-02-12 21:43:34.964468+00
99945bf1-c2b5-46af-82fb-94258630fcc1	00000000-0000-4000-a000-000000000001	admin	POST	/api/v1/vitals	\N	{"status": 422, "duration_ms": 6}	127.0.0.1	2026-02-12 21:44:01.323312+00
1255ec3e-aded-4e9d-97ea-ab97b57d0cd4	00000000-0000-4000-a000-000000000001	admin	POST	/api/v1/vitals	\N	{"status": 422, "duration_ms": 6}	127.0.0.1	2026-02-12 21:44:19.908816+00
e9678cba-09ed-4a51-aa5d-f03ae76bf3d6	00000000-0000-4000-a000-000000000001	admin	POST	/api/v1/vitals	\N	{"status": 422, "duration_ms": 5}	127.0.0.1	2026-02-12 21:45:26.827769+00
4612e563-e687-4e29-8908-077731541b22	00000000-0000-4000-a000-000000000001	admin	POST	/api/v1/vitals	\N	{"status": 422, "duration_ms": 5}	127.0.0.1	2026-02-12 21:50:10.512627+00
825ae1fb-7fa8-4504-8efd-85c960bbd6ea	00000000-0000-4000-a000-000000000001	admin	POST	/api/v1/vitals	\N	{"status": 422, "duration_ms": 5}	127.0.0.1	2026-02-12 21:50:41.164555+00
f230a2f0-a391-41d3-93e6-94956772196a	00000000-0000-4000-a000-000000000001	admin	POST	/api/v1/vitals	\N	{"status": 422, "duration_ms": 6}	127.0.0.1	2026-02-12 21:51:50.00943+00
c92005d5-86fa-471f-9ba5-854e1856f609	00000000-0000-4000-a000-000000000001	admin	POST	/api/v1/vitals	\N	{"status": 422, "duration_ms": 8}	127.0.0.1	2026-02-12 21:52:09.017842+00
\.


--
-- TOC entry 4425 (class 0 OID 32924)
-- Dependencies: 306
-- Data for Name: clinical_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clinical_notes (id, patient_id, encounter_id, note_type, title, content, summary, author_id, co_signed_by, co_signed_at, status, is_confidential, tags, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4426 (class 0 OID 32947)
-- Dependencies: 307
-- Data for Name: consents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consents (id, patient_id, consent_type, status, granted_at, granted_by, valid_from, valid_until, revoked_at, revoked_reason, witness_name, notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4442 (class 0 OID 65709)
-- Dependencies: 323
-- Data for Name: consultations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consultations (id, patient_id, encounter_id, specialty, urgency, question, clinical_context, requested_by, requested_at, consultant_id, consultant_name, response, recommendations, responded_at, status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4431 (class 0 OID 33028)
-- Dependencies: 312
-- Data for Name: death_notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.death_notifications (id, patient_id, contact_name, contact_phone, contact_email, contact_role, emergency_contact_id, priority, instructions, created_at) FROM stdin;
\.


--
-- TOC entry 4432 (class 0 OID 33046)
-- Dependencies: 313
-- Data for Name: discharge_criteria; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discharge_criteria (id, patient_id, encounter_id, planned_discharge_date, actual_discharge_date, crp_declining, crp_below_50, afebrile_48h, oral_stable_48h, clinical_improvement, aftercare_organized, followup_gp, followup_gp_date, followup_spitex, followup_spitex_date, notes, updated_at) FROM stdin;
\.


--
-- TOC entry 4416 (class 0 OID 26198)
-- Dependencies: 297
-- Data for Name: emergency_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.emergency_contacts (id, patient_id, name, relationship_type, phone, is_primary, email, address, priority, is_legal_representative, is_key_person, notes) FROM stdin;
\.


--
-- TOC entry 4417 (class 0 OID 26208)
-- Dependencies: 298
-- Data for Name: encounters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.encounters (id, patient_id, status, encounter_type, ward, bed, admitted_at, discharged_at, reason, attending_physician_id) FROM stdin;
\.


--
-- TOC entry 4439 (class 0 OID 65652)
-- Dependencies: 320
-- Data for Name: fluid_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fluid_entries (id, patient_id, encounter_id, direction, category, display_name, volume_ml, route, recorded_at, recorded_by, notes, created_at) FROM stdin;
\.


--
-- TOC entry 4435 (class 0 OID 40995)
-- Dependencies: 316
-- Data for Name: home_visits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.home_visits (id, patient_id, appointment_id, encounter_id, assigned_nurse_id, assigned_nurse_name, status, planned_date, planned_start, planned_end, actual_arrival, actual_departure, travel_time_minutes, visit_duration_minutes, vital_signs_recorded, medication_administered, wound_care_performed, iv_therapy_performed, blood_drawn, patient_condition, documentation, notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4418 (class 0 OID 26221)
-- Dependencies: 299
-- Data for Name: insurances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.insurances (id, patient_id, insurer_name, policy_number, insurance_type, valid_from, valid_until, franchise, kostengutsprache, kostengutsprache_bis, garant, bvg_number, notes) FROM stdin;
\.


--
-- TOC entry 4438 (class 0 OID 65630)
-- Dependencies: 319
-- Data for Name: lab_results; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lab_results (id, patient_id, encounter_id, analyte, loinc_code, display_name, value, unit, ref_min, ref_max, flag, interpretation, trend, previous_value, category, sample_type, collected_at, resulted_at, ordered_by, validated_by, order_number, notes, extra, created_at) FROM stdin;
\.


--
-- TOC entry 4443 (class 0 OID 65732)
-- Dependencies: 324
-- Data for Name: medical_letters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medical_letters (id, patient_id, encounter_id, letter_type, title, recipient_name, recipient_institution, recipient_email, diagnosis, history, findings, therapy, procedures, recommendations, medication_on_discharge, follow_up, content, author_id, co_signed_by, co_signed_at, status, sent_at, sent_via, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4427 (class 0 OID 32960)
-- Dependencies: 308
-- Data for Name: medical_providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medical_providers (id, patient_id, provider_type, name, contact_person, phone, email, hin_email, gln_number, address, speciality, notes) FROM stdin;
\.


--
-- TOC entry 4422 (class 0 OID 32869)
-- Dependencies: 303
-- Data for Name: medication_administrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medication_administrations (id, medication_id, patient_id, administered_at, administered_by, dose_given, dose_unit, route, status, reason_not_given, notes) FROM stdin;
\.


--
-- TOC entry 4421 (class 0 OID 32851)
-- Dependencies: 302
-- Data for Name: medications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medications (id, patient_id, encounter_id, name, generic_name, atc_code, dose, dose_unit, route, frequency, start_date, end_date, status, reason, notes, prescribed_by, is_prn, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4423 (class 0 OID 32888)
-- Dependencies: 304
-- Data for Name: nursing_assessments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nursing_assessments (id, patient_id, encounter_id, assessment_type, total_score, max_score, risk_level, items, notes, assessed_at, assessed_by, created_at) FROM stdin;
\.


--
-- TOC entry 4444 (class 0 OID 65753)
-- Dependencies: 325
-- Data for Name: nursing_diagnoses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nursing_diagnoses (id, patient_id, encounter_id, nanda_code, title, domain, defining_characteristics, related_factors, risk_factors, goals, interventions, evaluation, priority, status, diagnosed_by, diagnosed_at, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4424 (class 0 OID 32906)
-- Dependencies: 305
-- Data for Name: nursing_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nursing_entries (id, patient_id, encounter_id, category, title, content, priority, recorded_at, recorded_by, is_handover, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4446 (class 0 OID 65796)
-- Dependencies: 327
-- Data for Name: nutrition_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nutrition_orders (id, patient_id, encounter_id, diet_type, texture, supplements, restrictions, allergies, caloric_target, protein_target, fluid_target, special_instructions, status, start_date, end_date, ordered_by, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4447 (class 0 OID 65817)
-- Dependencies: 328
-- Data for Name: nutrition_screenings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nutrition_screenings (id, patient_id, screening_type, total_score, risk_level, items, notes, screened_at, screened_by, created_at) FROM stdin;
\.


--
-- TOC entry 4428 (class 0 OID 32973)
-- Dependencies: 309
-- Data for Name: palliative_care; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.palliative_care (id, patient_id, is_active, activated_at, activated_by, reserve_morphin, reserve_midazolam, reserve_haloperidol, reserve_scopolamin, reserve_other, palliative_service_name, palliative_service_phone, palliative_service_email, goals_of_care, notes, updated_at) FROM stdin;
\.


--
-- TOC entry 4433 (class 0 OID 33064)
-- Dependencies: 314
-- Data for Name: patient_wishes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patient_wishes (id, patient_id, quality_of_life, autonomy_preferences, pain_management, decision_maker, decision_maker_contact_id, sleep_preferences, nutrition_preferences, family_wishes, pet_info, spiritual_needs, other_wishes, recorded_by, recorded_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4415 (class 0 OID 26190)
-- Dependencies: 296
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patients (id, ahv_number, first_name, last_name, date_of_birth, gender, blood_type, phone, email, address_street, address_zip, address_city, address_canton, language, status, is_deleted, created_at, updated_at) FROM stdin;
1a571cdc-0bf1-4320-9118-6696374a5186	254.2455.1545.52	Sebastian	Setnescu	1971-11-28	male	\N	\N	\N	\N	\N	\N	\N	de	active	f	2026-02-10 14:33:31.703507+00	2026-02-10 14:33:31.703511+00
\.


--
-- TOC entry 4434 (class 0 OID 40982)
-- Dependencies: 315
-- Data for Name: remote_devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.remote_devices (id, patient_id, device_type, device_name, serial_number, manufacturer, is_online, last_seen_at, battery_level, last_reading_value, last_reading_unit, last_reading_at, alert_threshold_low, alert_threshold_high, installed_at, notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4436 (class 0 OID 41019)
-- Dependencies: 317
-- Data for Name: self_medication_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.self_medication_logs (id, patient_id, medication_id, scheduled_time, confirmed_at, status, notes, created_at) FROM stdin;
\.


--
-- TOC entry 4445 (class 0 OID 65776)
-- Dependencies: 326
-- Data for Name: shift_handovers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shift_handovers (id, patient_id, encounter_id, shift_type, handover_date, situation, background, assessment, recommendation, open_tasks, critical_info, handed_over_by, received_by, acknowledged_at, created_at) FROM stdin;
\.


--
-- TOC entry 4448 (class 0 OID 65833)
-- Dependencies: 329
-- Data for Name: supply_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supply_items (id, name, article_number, category, unit, stock_quantity, min_stock, is_active, created_at) FROM stdin;
\.


--
-- TOC entry 4449 (class 0 OID 65844)
-- Dependencies: 330
-- Data for Name: supply_usages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supply_usages (id, patient_id, supply_item_id, encounter_id, quantity, reason, used_at, used_by, created_at) FROM stdin;
\.


--
-- TOC entry 4437 (class 0 OID 41038)
-- Dependencies: 318
-- Data for Name: teleconsults; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.teleconsults (id, patient_id, appointment_id, encounter_id, physician_id, physician_name, status, meeting_link, meeting_platform, scheduled_start, scheduled_end, actual_start, actual_end, duration_minutes, soap_subjective, soap_objective, soap_assessment, soap_plan, technical_quality, followup_required, followup_notes, clinical_note_id, notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4441 (class 0 OID 65693)
-- Dependencies: 322
-- Data for Name: treatment_plan_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.treatment_plan_items (id, plan_id, item_type, description, frequency, duration, status, sort_order, notes, completed_at, completed_by, created_at) FROM stdin;
\.


--
-- TOC entry 4440 (class 0 OID 65671)
-- Dependencies: 321
-- Data for Name: treatment_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.treatment_plans (id, patient_id, encounter_id, title, diagnosis, icd_code, goals, interventions, start_date, target_date, end_date, status, priority, responsible_physician_id, created_by, review_date, notes, extra, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4419 (class 0 OID 26231)
-- Dependencies: 300
-- Data for Name: vital_signs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vital_signs (id, patient_id, encounter_id, recorded_at, recorded_by, source, heart_rate, systolic_bp, diastolic_bp, spo2, temperature, respiratory_rate, gcs, pain_score, extra) FROM stdin;
\.


--
-- TOC entry 4456 (class 0 OID 0)
-- Dependencies: 251
-- Name: bgw_job_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: -
--

SELECT pg_catalog.setval('_timescaledb_catalog.bgw_job_id_seq', 1000, false);


--
-- TOC entry 4457 (class 0 OID 0)
-- Dependencies: 249
-- Name: chunk_column_stats_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: -
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_column_stats_id_seq', 1, false);


--
-- TOC entry 4458 (class 0 OID 0)
-- Dependencies: 248
-- Name: chunk_constraint_name; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: -
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_constraint_name', 1, false);


--
-- TOC entry 4459 (class 0 OID 0)
-- Dependencies: 245
-- Name: chunk_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: -
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_id_seq', 1, false);


--
-- TOC entry 4460 (class 0 OID 0)
-- Dependencies: 270
-- Name: continuous_agg_migrate_plan_step_step_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: -
--

SELECT pg_catalog.setval('_timescaledb_catalog.continuous_agg_migrate_plan_step_step_id_seq', 1, false);


--
-- TOC entry 4461 (class 0 OID 0)
-- Dependencies: 241
-- Name: dimension_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: -
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_id_seq', 2, true);


--
-- TOC entry 4462 (class 0 OID 0)
-- Dependencies: 243
-- Name: dimension_slice_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: -
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_slice_id_seq', 1, false);


--
-- TOC entry 4463 (class 0 OID 0)
-- Dependencies: 237
-- Name: hypertable_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: -
--

SELECT pg_catalog.setval('_timescaledb_catalog.hypertable_id_seq', 2, true);


--
-- TOC entry 4120 (class 2606 OID 32992)
-- Name: advance_directives advance_directives_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advance_directives
    ADD CONSTRAINT advance_directives_pkey PRIMARY KEY (id);


--
-- TOC entry 4089 (class 2606 OID 26253)
-- Name: alarms alarms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alarms
    ADD CONSTRAINT alarms_pkey PRIMARY KEY (id);


--
-- TOC entry 4067 (class 2606 OID 26173)
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- TOC entry 4069 (class 2606 OID 26180)
-- Name: app_users app_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_users
    ADD CONSTRAINT app_users_pkey PRIMARY KEY (id);


--
-- TOC entry 4123 (class 2606 OID 33010)
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- TOC entry 4072 (class 2606 OID 26188)
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 4105 (class 2606 OID 32932)
-- Name: clinical_notes clinical_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_pkey PRIMARY KEY (id);


--
-- TOC entry 4111 (class 2606 OID 32953)
-- Name: consents consents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consents
    ADD CONSTRAINT consents_pkey PRIMARY KEY (id);


--
-- TOC entry 4166 (class 2606 OID 65720)
-- Name: consultations consultations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_pkey PRIMARY KEY (id);


--
-- TOC entry 4127 (class 2606 OID 33034)
-- Name: death_notifications death_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.death_notifications
    ADD CONSTRAINT death_notifications_pkey PRIMARY KEY (id);


--
-- TOC entry 4130 (class 2606 OID 33052)
-- Name: discharge_criteria discharge_criteria_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discharge_criteria
    ADD CONSTRAINT discharge_criteria_pkey PRIMARY KEY (id);


--
-- TOC entry 4078 (class 2606 OID 26202)
-- Name: emergency_contacts emergency_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.emergency_contacts
    ADD CONSTRAINT emergency_contacts_pkey PRIMARY KEY (id);


--
-- TOC entry 4080 (class 2606 OID 26214)
-- Name: encounters encounters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encounters
    ADD CONSTRAINT encounters_pkey PRIMARY KEY (id);


--
-- TOC entry 4156 (class 2606 OID 65658)
-- Name: fluid_entries fluid_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fluid_entries
    ADD CONSTRAINT fluid_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 4139 (class 2606 OID 41001)
-- Name: home_visits home_visits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_visits
    ADD CONSTRAINT home_visits_pkey PRIMARY KEY (id);


--
-- TOC entry 4083 (class 2606 OID 26225)
-- Name: insurances insurances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.insurances
    ADD CONSTRAINT insurances_pkey PRIMARY KEY (id);


--
-- TOC entry 4154 (class 2606 OID 65637)
-- Name: lab_results lab_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lab_results
    ADD CONSTRAINT lab_results_pkey PRIMARY KEY (id);


--
-- TOC entry 4170 (class 2606 OID 65741)
-- Name: medical_letters medical_letters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_letters
    ADD CONSTRAINT medical_letters_pkey PRIMARY KEY (id);


--
-- TOC entry 4115 (class 2606 OID 32966)
-- Name: medical_providers medical_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_providers
    ADD CONSTRAINT medical_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4097 (class 2606 OID 32875)
-- Name: medication_administrations medication_administrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_administrations
    ADD CONSTRAINT medication_administrations_pkey PRIMARY KEY (id);


--
-- TOC entry 4093 (class 2606 OID 32857)
-- Name: medications medications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medications
    ADD CONSTRAINT medications_pkey PRIMARY KEY (id);


--
-- TOC entry 4100 (class 2606 OID 32894)
-- Name: nursing_assessments nursing_assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nursing_assessments
    ADD CONSTRAINT nursing_assessments_pkey PRIMARY KEY (id);


--
-- TOC entry 4173 (class 2606 OID 65764)
-- Name: nursing_diagnoses nursing_diagnoses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nursing_diagnoses
    ADD CONSTRAINT nursing_diagnoses_pkey PRIMARY KEY (id);


--
-- TOC entry 4103 (class 2606 OID 32912)
-- Name: nursing_entries nursing_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nursing_entries
    ADD CONSTRAINT nursing_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 4180 (class 2606 OID 65805)
-- Name: nutrition_orders nutrition_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_orders
    ADD CONSTRAINT nutrition_orders_pkey PRIMARY KEY (id);


--
-- TOC entry 4183 (class 2606 OID 65826)
-- Name: nutrition_screenings nutrition_screenings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_screenings
    ADD CONSTRAINT nutrition_screenings_pkey PRIMARY KEY (id);


--
-- TOC entry 4118 (class 2606 OID 32979)
-- Name: palliative_care palliative_care_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.palliative_care
    ADD CONSTRAINT palliative_care_pkey PRIMARY KEY (id);


--
-- TOC entry 4134 (class 2606 OID 33070)
-- Name: patient_wishes patient_wishes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_wishes
    ADD CONSTRAINT patient_wishes_pkey PRIMARY KEY (id);


--
-- TOC entry 4076 (class 2606 OID 26196)
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- TOC entry 4137 (class 2606 OID 40988)
-- Name: remote_devices remote_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_devices
    ADD CONSTRAINT remote_devices_pkey PRIMARY KEY (id);


--
-- TOC entry 4145 (class 2606 OID 41025)
-- Name: self_medication_logs self_medication_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.self_medication_logs
    ADD CONSTRAINT self_medication_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 4177 (class 2606 OID 65783)
-- Name: shift_handovers shift_handovers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_handovers
    ADD CONSTRAINT shift_handovers_pkey PRIMARY KEY (id);


--
-- TOC entry 4185 (class 2606 OID 65843)
-- Name: supply_items supply_items_article_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_items
    ADD CONSTRAINT supply_items_article_number_key UNIQUE (article_number);


--
-- TOC entry 4187 (class 2606 OID 65841)
-- Name: supply_items supply_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_items
    ADD CONSTRAINT supply_items_pkey PRIMARY KEY (id);


--
-- TOC entry 4191 (class 2606 OID 65852)
-- Name: supply_usages supply_usages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_usages
    ADD CONSTRAINT supply_usages_pkey PRIMARY KEY (id);


--
-- TOC entry 4148 (class 2606 OID 41044)
-- Name: teleconsults teleconsults_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teleconsults
    ADD CONSTRAINT teleconsults_pkey PRIMARY KEY (id);


--
-- TOC entry 4164 (class 2606 OID 65702)
-- Name: treatment_plan_items treatment_plan_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treatment_plan_items
    ADD CONSTRAINT treatment_plan_items_pkey PRIMARY KEY (id);


--
-- TOC entry 4161 (class 2606 OID 65681)
-- Name: treatment_plans treatment_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treatment_plans
    ADD CONSTRAINT treatment_plans_pkey PRIMARY KEY (id);


--
-- TOC entry 4086 (class 2606 OID 26277)
-- Name: vital_signs vital_signs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vital_signs
    ADD CONSTRAINT vital_signs_pkey PRIMARY KEY (id, recorded_at);


--
-- TOC entry 4121 (class 1259 OID 33003)
-- Name: ix_advance_directives_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_advance_directives_patient_id ON public.advance_directives USING btree (patient_id);


--
-- TOC entry 4090 (class 1259 OID 26264)
-- Name: ix_alarms_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_alarms_patient_id ON public.alarms USING btree (patient_id);


--
-- TOC entry 4070 (class 1259 OID 26181)
-- Name: ix_app_users_keycloak_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_app_users_keycloak_id ON public.app_users USING btree (keycloak_id);


--
-- TOC entry 4124 (class 1259 OID 33026)
-- Name: ix_appointments_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_appointments_patient_id ON public.appointments USING btree (patient_id);


--
-- TOC entry 4125 (class 1259 OID 33027)
-- Name: ix_appointments_scheduled_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_appointments_scheduled_date ON public.appointments USING btree (scheduled_date);


--
-- TOC entry 4073 (class 1259 OID 26189)
-- Name: ix_audit_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- TOC entry 4106 (class 1259 OID 32946)
-- Name: ix_clinical_notes_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_clinical_notes_created_at ON public.clinical_notes USING btree (created_at);


--
-- TOC entry 4107 (class 1259 OID 32944)
-- Name: ix_clinical_notes_note_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_clinical_notes_note_type ON public.clinical_notes USING btree (note_type);


--
-- TOC entry 4108 (class 1259 OID 32943)
-- Name: ix_clinical_notes_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_clinical_notes_patient_id ON public.clinical_notes USING btree (patient_id);


--
-- TOC entry 4109 (class 1259 OID 32945)
-- Name: ix_clinical_notes_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_clinical_notes_status ON public.clinical_notes USING btree (status);


--
-- TOC entry 4112 (class 1259 OID 32959)
-- Name: ix_consents_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_consents_patient_id ON public.consents USING btree (patient_id);


--
-- TOC entry 4167 (class 1259 OID 65731)
-- Name: ix_consultations_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_consultations_patient_id ON public.consultations USING btree (patient_id);


--
-- TOC entry 4128 (class 1259 OID 33045)
-- Name: ix_death_notifications_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_death_notifications_patient_id ON public.death_notifications USING btree (patient_id);


--
-- TOC entry 4131 (class 1259 OID 33063)
-- Name: ix_discharge_criteria_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_discharge_criteria_patient_id ON public.discharge_criteria USING btree (patient_id);


--
-- TOC entry 4081 (class 1259 OID 26220)
-- Name: ix_encounters_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_encounters_patient_id ON public.encounters USING btree (patient_id);


--
-- TOC entry 4157 (class 1259 OID 65670)
-- Name: ix_fluid_entries_patient_direction_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fluid_entries_patient_direction_time ON public.fluid_entries USING btree (patient_id, direction, recorded_at);


--
-- TOC entry 4158 (class 1259 OID 65669)
-- Name: ix_fluid_entries_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fluid_entries_patient_id ON public.fluid_entries USING btree (patient_id);


--
-- TOC entry 4140 (class 1259 OID 41017)
-- Name: ix_home_visits_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_home_visits_patient_id ON public.home_visits USING btree (patient_id);


--
-- TOC entry 4141 (class 1259 OID 41018)
-- Name: ix_home_visits_planned_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_home_visits_planned_date ON public.home_visits USING btree (planned_date);


--
-- TOC entry 4149 (class 1259 OID 65649)
-- Name: ix_lab_results_analyte; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lab_results_analyte ON public.lab_results USING btree (analyte);


--
-- TOC entry 4150 (class 1259 OID 65650)
-- Name: ix_lab_results_order_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lab_results_order_number ON public.lab_results USING btree (order_number);


--
-- TOC entry 4151 (class 1259 OID 65651)
-- Name: ix_lab_results_patient_analyte_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lab_results_patient_analyte_time ON public.lab_results USING btree (patient_id, analyte, resulted_at);


--
-- TOC entry 4152 (class 1259 OID 65648)
-- Name: ix_lab_results_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lab_results_patient_id ON public.lab_results USING btree (patient_id);


--
-- TOC entry 4168 (class 1259 OID 65752)
-- Name: ix_medical_letters_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_medical_letters_patient_id ON public.medical_letters USING btree (patient_id);


--
-- TOC entry 4113 (class 1259 OID 32972)
-- Name: ix_medical_providers_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_medical_providers_patient_id ON public.medical_providers USING btree (patient_id);


--
-- TOC entry 4094 (class 1259 OID 32886)
-- Name: ix_medication_administrations_medication_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_medication_administrations_medication_id ON public.medication_administrations USING btree (medication_id);


--
-- TOC entry 4095 (class 1259 OID 32887)
-- Name: ix_medication_administrations_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_medication_administrations_patient_id ON public.medication_administrations USING btree (patient_id);


--
-- TOC entry 4091 (class 1259 OID 32868)
-- Name: ix_medications_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_medications_patient_id ON public.medications USING btree (patient_id);


--
-- TOC entry 4098 (class 1259 OID 32905)
-- Name: ix_nursing_assessments_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_nursing_assessments_patient_id ON public.nursing_assessments USING btree (patient_id);


--
-- TOC entry 4171 (class 1259 OID 65775)
-- Name: ix_nursing_diagnoses_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_nursing_diagnoses_patient_id ON public.nursing_diagnoses USING btree (patient_id);


--
-- TOC entry 4101 (class 1259 OID 32923)
-- Name: ix_nursing_entries_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_nursing_entries_patient_id ON public.nursing_entries USING btree (patient_id);


--
-- TOC entry 4178 (class 1259 OID 65816)
-- Name: ix_nutrition_orders_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_nutrition_orders_patient_id ON public.nutrition_orders USING btree (patient_id);


--
-- TOC entry 4181 (class 1259 OID 65832)
-- Name: ix_nutrition_screenings_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_nutrition_screenings_patient_id ON public.nutrition_screenings USING btree (patient_id);


--
-- TOC entry 4116 (class 1259 OID 32985)
-- Name: ix_palliative_care_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_palliative_care_patient_id ON public.palliative_care USING btree (patient_id);


--
-- TOC entry 4132 (class 1259 OID 33081)
-- Name: ix_patient_wishes_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_patient_wishes_patient_id ON public.patient_wishes USING btree (patient_id);


--
-- TOC entry 4074 (class 1259 OID 26197)
-- Name: ix_patients_ahv_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_patients_ahv_number ON public.patients USING btree (ahv_number);


--
-- TOC entry 4135 (class 1259 OID 40994)
-- Name: ix_remote_devices_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_remote_devices_patient_id ON public.remote_devices USING btree (patient_id);


--
-- TOC entry 4142 (class 1259 OID 41036)
-- Name: ix_self_medication_logs_medication_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_self_medication_logs_medication_id ON public.self_medication_logs USING btree (medication_id);


--
-- TOC entry 4143 (class 1259 OID 41037)
-- Name: ix_self_medication_logs_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_self_medication_logs_patient_id ON public.self_medication_logs USING btree (patient_id);


--
-- TOC entry 4174 (class 1259 OID 65795)
-- Name: ix_shift_handovers_handover_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shift_handovers_handover_date ON public.shift_handovers USING btree (handover_date);


--
-- TOC entry 4175 (class 1259 OID 65794)
-- Name: ix_shift_handovers_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shift_handovers_patient_id ON public.shift_handovers USING btree (patient_id);


--
-- TOC entry 4188 (class 1259 OID 65868)
-- Name: ix_supply_usages_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_supply_usages_patient_id ON public.supply_usages USING btree (patient_id);


--
-- TOC entry 4189 (class 1259 OID 65869)
-- Name: ix_supply_usages_supply_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_supply_usages_supply_item_id ON public.supply_usages USING btree (supply_item_id);


--
-- TOC entry 4146 (class 1259 OID 41060)
-- Name: ix_teleconsults_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_teleconsults_patient_id ON public.teleconsults USING btree (patient_id);


--
-- TOC entry 4162 (class 1259 OID 65708)
-- Name: ix_treatment_plan_items_plan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_treatment_plan_items_plan_id ON public.treatment_plan_items USING btree (plan_id);


--
-- TOC entry 4159 (class 1259 OID 65692)
-- Name: ix_treatment_plans_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_treatment_plans_patient_id ON public.treatment_plans USING btree (patient_id);


--
-- TOC entry 4084 (class 1259 OID 26248)
-- Name: ix_vital_signs_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vital_signs_patient_id ON public.vital_signs USING btree (patient_id);


--
-- TOC entry 4087 (class 1259 OID 26278)
-- Name: vital_signs_recorded_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vital_signs_recorded_at_idx ON public.vital_signs USING btree (recorded_at DESC);


--
-- TOC entry 4211 (class 2606 OID 32993)
-- Name: advance_directives advance_directives_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advance_directives
    ADD CONSTRAINT advance_directives_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4212 (class 2606 OID 32998)
-- Name: advance_directives advance_directives_trusted_person_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advance_directives
    ADD CONSTRAINT advance_directives_trusted_person_contact_id_fkey FOREIGN KEY (trusted_person_contact_id) REFERENCES public.emergency_contacts(id);


--
-- TOC entry 4197 (class 2606 OID 26254)
-- Name: alarms alarms_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alarms
    ADD CONSTRAINT alarms_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4213 (class 2606 OID 33011)
-- Name: appointments appointments_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4214 (class 2606 OID 33016)
-- Name: appointments appointments_parent_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_parent_appointment_id_fkey FOREIGN KEY (parent_appointment_id) REFERENCES public.appointments(id);


--
-- TOC entry 4215 (class 2606 OID 33021)
-- Name: appointments appointments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4206 (class 2606 OID 32933)
-- Name: clinical_notes clinical_notes_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4207 (class 2606 OID 32938)
-- Name: clinical_notes clinical_notes_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4208 (class 2606 OID 32954)
-- Name: consents consents_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consents
    ADD CONSTRAINT consents_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4238 (class 2606 OID 65726)
-- Name: consultations consultations_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4239 (class 2606 OID 65721)
-- Name: consultations consultations_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4216 (class 2606 OID 33035)
-- Name: death_notifications death_notifications_emergency_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.death_notifications
    ADD CONSTRAINT death_notifications_emergency_contact_id_fkey FOREIGN KEY (emergency_contact_id) REFERENCES public.emergency_contacts(id);


--
-- TOC entry 4217 (class 2606 OID 33040)
-- Name: death_notifications death_notifications_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.death_notifications
    ADD CONSTRAINT death_notifications_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4218 (class 2606 OID 33053)
-- Name: discharge_criteria discharge_criteria_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discharge_criteria
    ADD CONSTRAINT discharge_criteria_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4219 (class 2606 OID 33058)
-- Name: discharge_criteria discharge_criteria_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discharge_criteria
    ADD CONSTRAINT discharge_criteria_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4192 (class 2606 OID 26203)
-- Name: emergency_contacts emergency_contacts_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.emergency_contacts
    ADD CONSTRAINT emergency_contacts_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4193 (class 2606 OID 26215)
-- Name: encounters encounters_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encounters
    ADD CONSTRAINT encounters_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4233 (class 2606 OID 65664)
-- Name: fluid_entries fluid_entries_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fluid_entries
    ADD CONSTRAINT fluid_entries_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4234 (class 2606 OID 65659)
-- Name: fluid_entries fluid_entries_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fluid_entries
    ADD CONSTRAINT fluid_entries_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4223 (class 2606 OID 41002)
-- Name: home_visits home_visits_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_visits
    ADD CONSTRAINT home_visits_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id);


--
-- TOC entry 4224 (class 2606 OID 41007)
-- Name: home_visits home_visits_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_visits
    ADD CONSTRAINT home_visits_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4225 (class 2606 OID 41012)
-- Name: home_visits home_visits_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_visits
    ADD CONSTRAINT home_visits_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4194 (class 2606 OID 26226)
-- Name: insurances insurances_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.insurances
    ADD CONSTRAINT insurances_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4231 (class 2606 OID 65643)
-- Name: lab_results lab_results_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lab_results
    ADD CONSTRAINT lab_results_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4232 (class 2606 OID 65638)
-- Name: lab_results lab_results_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lab_results
    ADD CONSTRAINT lab_results_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4240 (class 2606 OID 65747)
-- Name: medical_letters medical_letters_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_letters
    ADD CONSTRAINT medical_letters_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4241 (class 2606 OID 65742)
-- Name: medical_letters medical_letters_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_letters
    ADD CONSTRAINT medical_letters_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4209 (class 2606 OID 32967)
-- Name: medical_providers medical_providers_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_providers
    ADD CONSTRAINT medical_providers_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4200 (class 2606 OID 32876)
-- Name: medication_administrations medication_administrations_medication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_administrations
    ADD CONSTRAINT medication_administrations_medication_id_fkey FOREIGN KEY (medication_id) REFERENCES public.medications(id) ON DELETE CASCADE;


--
-- TOC entry 4201 (class 2606 OID 32881)
-- Name: medication_administrations medication_administrations_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_administrations
    ADD CONSTRAINT medication_administrations_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4198 (class 2606 OID 32858)
-- Name: medications medications_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medications
    ADD CONSTRAINT medications_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4199 (class 2606 OID 32863)
-- Name: medications medications_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medications
    ADD CONSTRAINT medications_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4202 (class 2606 OID 32895)
-- Name: nursing_assessments nursing_assessments_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nursing_assessments
    ADD CONSTRAINT nursing_assessments_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4203 (class 2606 OID 32900)
-- Name: nursing_assessments nursing_assessments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nursing_assessments
    ADD CONSTRAINT nursing_assessments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4242 (class 2606 OID 65770)
-- Name: nursing_diagnoses nursing_diagnoses_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nursing_diagnoses
    ADD CONSTRAINT nursing_diagnoses_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4243 (class 2606 OID 65765)
-- Name: nursing_diagnoses nursing_diagnoses_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nursing_diagnoses
    ADD CONSTRAINT nursing_diagnoses_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4204 (class 2606 OID 32913)
-- Name: nursing_entries nursing_entries_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nursing_entries
    ADD CONSTRAINT nursing_entries_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4205 (class 2606 OID 32918)
-- Name: nursing_entries nursing_entries_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nursing_entries
    ADD CONSTRAINT nursing_entries_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4246 (class 2606 OID 65811)
-- Name: nutrition_orders nutrition_orders_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_orders
    ADD CONSTRAINT nutrition_orders_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4247 (class 2606 OID 65806)
-- Name: nutrition_orders nutrition_orders_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_orders
    ADD CONSTRAINT nutrition_orders_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4248 (class 2606 OID 65827)
-- Name: nutrition_screenings nutrition_screenings_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_screenings
    ADD CONSTRAINT nutrition_screenings_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4210 (class 2606 OID 32980)
-- Name: palliative_care palliative_care_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.palliative_care
    ADD CONSTRAINT palliative_care_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4220 (class 2606 OID 33071)
-- Name: patient_wishes patient_wishes_decision_maker_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_wishes
    ADD CONSTRAINT patient_wishes_decision_maker_contact_id_fkey FOREIGN KEY (decision_maker_contact_id) REFERENCES public.emergency_contacts(id);


--
-- TOC entry 4221 (class 2606 OID 33076)
-- Name: patient_wishes patient_wishes_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_wishes
    ADD CONSTRAINT patient_wishes_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4222 (class 2606 OID 40989)
-- Name: remote_devices remote_devices_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_devices
    ADD CONSTRAINT remote_devices_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4226 (class 2606 OID 41026)
-- Name: self_medication_logs self_medication_logs_medication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.self_medication_logs
    ADD CONSTRAINT self_medication_logs_medication_id_fkey FOREIGN KEY (medication_id) REFERENCES public.medications(id);


--
-- TOC entry 4227 (class 2606 OID 41031)
-- Name: self_medication_logs self_medication_logs_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.self_medication_logs
    ADD CONSTRAINT self_medication_logs_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4244 (class 2606 OID 65789)
-- Name: shift_handovers shift_handovers_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_handovers
    ADD CONSTRAINT shift_handovers_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4245 (class 2606 OID 65784)
-- Name: shift_handovers shift_handovers_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_handovers
    ADD CONSTRAINT shift_handovers_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4249 (class 2606 OID 65863)
-- Name: supply_usages supply_usages_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_usages
    ADD CONSTRAINT supply_usages_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4250 (class 2606 OID 65853)
-- Name: supply_usages supply_usages_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_usages
    ADD CONSTRAINT supply_usages_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4251 (class 2606 OID 65858)
-- Name: supply_usages supply_usages_supply_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_usages
    ADD CONSTRAINT supply_usages_supply_item_id_fkey FOREIGN KEY (supply_item_id) REFERENCES public.supply_items(id);


--
-- TOC entry 4228 (class 2606 OID 41045)
-- Name: teleconsults teleconsults_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teleconsults
    ADD CONSTRAINT teleconsults_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id);


--
-- TOC entry 4229 (class 2606 OID 41050)
-- Name: teleconsults teleconsults_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teleconsults
    ADD CONSTRAINT teleconsults_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4230 (class 2606 OID 41055)
-- Name: teleconsults teleconsults_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teleconsults
    ADD CONSTRAINT teleconsults_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4237 (class 2606 OID 65703)
-- Name: treatment_plan_items treatment_plan_items_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treatment_plan_items
    ADD CONSTRAINT treatment_plan_items_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.treatment_plans(id) ON DELETE CASCADE;


--
-- TOC entry 4235 (class 2606 OID 65687)
-- Name: treatment_plans treatment_plans_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treatment_plans
    ADD CONSTRAINT treatment_plans_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4236 (class 2606 OID 65682)
-- Name: treatment_plans treatment_plans_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treatment_plans
    ADD CONSTRAINT treatment_plans_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 4195 (class 2606 OID 26238)
-- Name: vital_signs vital_signs_encounter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vital_signs
    ADD CONSTRAINT vital_signs_encounter_id_fkey FOREIGN KEY (encounter_id) REFERENCES public.encounters(id);


--
-- TOC entry 4196 (class 2606 OID 26243)
-- Name: vital_signs vital_signs_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vital_signs
    ADD CONSTRAINT vital_signs_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


-- Completed on 2026-02-13 06:03:21 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict FenfKBKadz5FnKWfLHTndNCG0WKEPGz8rashJ1zxBDeElLdThYvTjKXhYtxsSvC

